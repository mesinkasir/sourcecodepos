# Axcora Spectre apps

Open source code free download gratis point of sale apps.

![free download source code pos](https://1.bp.blogspot.com/-qD0C7BfujUE/YJwevBulxLI/AAAAAAAAN6s/TsTtcEr6scY56FRfwVeiOQOvHwG7GGS5ACLcBGAsYHQ/s1920/1.jpg)

Modern UI blast and fast with axcora spectre pos

![free download source code pos](https://1.bp.blogspot.com/-ED4grKUPAEk/YJwevHl6xiI/AAAAAAAAN6w/8w90RzEgLAcarZl3UItjWzex29vaMIutgCLcBGAsYHQ/s1920/2.jpg)

Multi device support

![free download source code pos](https://1.bp.blogspot.com/--wSuVTVJURA/YJwe6GV5X8I/AAAAAAAAN7Q/GTFrj9zK_lIS280BBDGtgPzTDgK93ZxFACLcBGAsYHQ/s537/login.png)

Login page area

![free download source code pos](https://1.bp.blogspot.com/-d91dGyejlig/YJwe2AFRFpI/AAAAAAAAN68/O-wsdNe3i1IrWZLm4FGPYN8KFOXwFYZsQCLcBGAsYHQ/s693/Screenshot_2021-05-12%2BAxcora%2BSpectre%2BApps.png)

Mobile POS point of sale cashier

![free download source code pos](https://1.bp.blogspot.com/-sAITylmiVgY/YJwe5vkJXZI/AAAAAAAAN7M/W0B7ss16rK0Wn3lE0w3p9nBZ5Ft7E0dLwCLcBGAsYHQ/s1356/Screenshot_2021-05-12%2BMedical%2BStore%25282%2529.png)

Desktop Point of sale apps

![free download source code pos](https://1.bp.blogspot.com/-eH2zO9XduD0/YJwe47TPnPI/AAAAAAAAN7E/X4JC0p7KhhM4v_GDY6aBArKJNgx7_xwcwCLcBGAsYHQ/s1366/Screenshot_2021-05-12%2BMedical%2BStore%25284%2529.png)

Cashier Transaction & Customer Paymet

![free download source code pos](https://1.bp.blogspot.com/-nijs_onNcmA/YJwe5C8i-YI/AAAAAAAAN7I/SL0gYWrhKxoTBMXSGx5Gm_JR30PeK1cRQCLcBGAsYHQ/s1349/Screenshot_2021-05-12%2BMedical%2BStore%25285%2529.png)

Print out receipt or invoice mode

![free download source code pos](https://1.bp.blogspot.com/-_Iyp_LdM400/YJwe6I8iF7I/AAAAAAAAN7U/_bSjZbcWLnQkRL93jgIB2WyGTdcQ9eQXQCLcBGAsYHQ/s1366/Screenshot_2021-05-12%2BMedical%2BStore%25286%2529.png)

All report details.

-------------------------------------------------------

Free download gratis !!

How to install and work with this apps ?? read documentation here :
[https://axcora.com/source-code-pos-free-download-gratis.html](https://axcora.com/source-code-pos-free-download-gratis.html)

Demo :
[https://axcora.my.id/spectrepos](https://axcora.my.id/spectrepos)