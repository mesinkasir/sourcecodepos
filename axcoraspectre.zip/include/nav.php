<div class="col-12 text-center">
 <img width="80" src="https://mesinkasironline.web.app/img/createwebsiteusingangular.png" alt="Free download open source code point of sale web apps">
 </div>
<header class="navbar shadow">
   
<!--  <section class="navbar-section">
    <a href="cat.php" class="btn btn-link">Youtube</a>
  </section> -->
   
  <section class="navbar-center">
    <!-- centered logo or brand -->

	<div class="dropdown">
  <a href="#" class="btn btn-primary dropdown-toggle" tabindex="0">
 Axcora Spectre Menu
  </a>
  <!-- menu component -->
 <ul class="menu nav">
  <li class="nav-item">
    <a href="index.php" class="text-primary"><i class="icon icon-apps"></i> Home</a>
  </li>
  <li class="nav-item">
    <a href="manageCat.php" class="text-primary"><i class="icon icon-bookmark"></i> Group</a>
  </li>
  <li class="nav-item">
    <a href="products.php" class="text-primary"><i class="icon icon-link"></i> Product</a>
  </li>
    <li class="nav-item">
    <a href="pos.php" class="text-primary"><i class="icon icon-photo"></i> POS</a>
  </li>
    <li class="nav-item">
    <a href="reports.php" class="text-primary"><i class="icon icon-time"></i> Report</a>
  </li>
    <li class="nav-item">
    <a href="setting.php" class="text-primary"><i class="icon icon-more-horiz"></i> Setting</a>
  </li>
    <li class="nav-item">
    <a href="doc.php" class="text-primary" target="_blank"><i class="icon icon-message"></i> Documentation</a>
  </li>
    <li class="nav-item">
    <a href="logout.php" class="text-primary"><i class="icon icon-shutdown"></i> Log Out</a>
  </li>
</ul>
</div>
	<!-- end -->
  </section>
 <!--  <section class="navbar-section">
    <a href="#" class="btn btn-link">GitHub</a>
  </section> -->
</header>
